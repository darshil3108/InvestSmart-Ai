from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate,login
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login
from django.contrib import messages
from django.http import JsonResponse
from django.db.models import Sum
from .models import UserProfile, Portfolio, Holding, Transaction, AIRecommendation, ChatMessage, TaxCalculation
from .forms import UserRegistrationForm, UserProfileForm, PortfolioForm, HoldingForm, TransactionForm, TaxCalculationForm, AIAdvisorForm
import yfinance as yf
from django.shortcuts import render
from .models import Holding
from decimal import Decimal
import json
import datetime
from .models import AssetAllocation
from .forms import ChatForm
from .models import ChatMessage, Recommendation
import random
import yfinance as yf
import pandas as pd
import matplotlib.pyplot as plt
import io
import base64
from django.shortcuts import render
from django.http import HttpResponse
from django.contrib.auth.backends import ModelBackend


# ✅ Nifty 50 Stocks List
nifty50_stocks = [
    # 📌 NSE Stocks (End with .NS)
    "RELIANCE.NS", "TCS.NS", "INFY.NS", "HDFCBANK.NS", "ICICIBANK.NS",
    "HINDUNILVR.NS", "ITC.NS", "KOTAKBANK.NS", "LT.NS", "SBIN.NS",
    "BAJFINANCE.NS", "BHARTIARTL.NS", "ASIANPAINT.NS", "HCLTECH.NS",
    "MARUTI.NS", "TITAN.NS", "AXISBANK.NS", "SUNPHARMA.NS", "ULTRACEMCO.NS",
    "TATASTEEL.NS", "ADANIENT.NS", "JSWSTEEL.NS", "M&M.NS", "GRASIM.NS",
    "COALINDIA.NS", "ONGC.NS", "NTPC.NS", "BPCL.NS", "TATAMOTORS.NS",

    # 📌 BSE Stocks (End with .BO)
    "RELIANCE.BO", "TCS.BO", "INFY.BO", "HDFCBANK.BO", "ICICIBANK.BO",
    "HINDUNILVR.BO", "ITC.BO", "KOTAKBANK.BO", "LT.BO", "SBIN.BO",
    "BAJFINANCE.BO", "BHARTIARTL.BO", "ASIANPAINT.BO", "HCLTECH.BO",
    "MARUTI.BO", "TITAN.BO", "AXISBANK.BO", "SUNPHARMA.BO", "ULTRACEMCO.BO",
    "TATASTEEL.BO", "ADANIENT.BO", "JSWSTEEL.BO", "M&M.BO", "GRASIM.BO",
    "COALINDIA.BO", "ONGC.BO", "NTPC.BO", "BPCL.BO", "TATAMOTORS.BO"
]



# ✅ Fetch stock data
def portfolio_stock_dashboard(request):
    all_stock_data = []
    sr_no = 1  

    for symbol in nifty50_stocks:
        stock = yf.Ticker(symbol)
        data = stock.history(period="1d")
        
        if not data.empty:
            all_stock_data.append([
                sr_no, symbol,  
                round(data["Open"].iloc[0], 2),  
                round(data["High"].iloc[0], 2),  
                round(data["Low"].iloc[0], 2),   
                round(data["Close"].iloc[0], 2)  
            ])
            sr_no += 1  

    df = pd.DataFrame(all_stock_data, columns=["SR No.", "Stock Symbol", "Open", "High", "Low", "Close"])
    
    return render(request, 'dashboard/portfolio.html', {'stock_data': df})

# ✅ Stock Chart View
def stock_chart(request, symbol):
    stock = yf.Ticker(symbol)
    data = stock.history(period="7d")  

    plt.figure(figsize=(9, 5))
    plt.plot(data.index, data["Close"], marker='o', linestyle='-')
    plt.xlabel("Date")
    plt.ylabel("Close Price (INR)")
    plt.title(f"Stock Price Chart: {symbol}")
    plt.grid(True)

    # Rotate the x-axis labels
    plt.xticks(rotation=45)  # Rotate x-axis labels by 45 degrees

    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_png = buffer.getvalue()
    buffer.close()
    
    image_base64 = base64.b64encode(image_png).decode("utf-8")
    return HttpResponse(f'<img src="data:image/png;base64,{image_base64}"/>')

# ✅ Stock Prediction View
# ✅ Stock Prediction View
def predict_stock(request, symbol):
    stock = yf.Ticker(symbol)
    data = stock.history(period="30d")

    # Simple moving average prediction
    data["Prediction"] = data["Close"].rolling(window=3).mean()

    plt.figure(figsize=(9, 5))
    plt.plot(data.index, data["Close"], marker='o', label="Actual Price", linestyle='-')
    plt.plot(data.index, data["Prediction"], marker='x', label="Predicted Price", linestyle='--')
    plt.xlabel("Date")
    plt.ylabel("Stock Price (INR)")
    plt.title(f"Stock Price Prediction: {symbol}")
    plt.legend()
    plt.grid(True)

    # 🔴 FIX: Encode the image to base64
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_png = buffer.getvalue()
    buffer.close()
    
    image_base64 = base64.b64encode(image_png).decode("utf-8")  # ✅ Fix: Define image_base64

    return HttpResponse(f'<img src="data:image/png;base64,{image_base64}"/>')


def asset_allocation_chart(request):
    allocations = AssetAllocation.objects.all()
    labels = [allocation.asset_type for allocation in allocations]
    values = [allocation.value for allocation in allocations]

    context = {
        'labels': labels,
        'values': values,
    }
    return render(request, 'dashboard/asset_allocation_chart.html', context)

def index(request):
    return render(request, 'dashboard/index.html')

def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            UserProfile.objects.create(user=user)
            user.backend = 'django.contrib.auth.backends.ModelBackend'
            login(request, user)
            messages.success(request, 'Account created successfully!')
            return redirect('dashboard')
    else:
        form = UserRegistrationForm()
    return render(request, 'dashboard/register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')  # Redirect to home after successful login
        else:
            # Handle invalid login
            return render(request, 'main/login.html', {'error': 'Invalid username or password'})
    return render(request, 'main/login.html')

@login_required
def dashboard(request):
    # Indian stock holdings
    predefined_holdings = [
        {
            'symbol': 'RELIANCE.NS',
            'name': 'Reliance Industries Ltd.',
            'shares': 10,
            'purchase_price': 2400.00,
        },
        {
            'symbol': 'TCS.NS',
            'name': 'Tata Consultancy Services Ltd.',
            'shares': 5,
            'purchase_price': 3500.00,
        },
        {
            'symbol': 'INFY.NS',
            'name': 'Infosys Ltd.',
            'shares': 8,
            'purchase_price': 1600.00,
        },
        {
            'symbol': 'HDFCBANK.NS',
            'name': 'HDFC Bank Ltd.',
            'shares': 12,
            'purchase_price': 1450.00,
        },
        {
            'symbol': 'ITC.NS',
            'name': 'ITC Ltd.',
            'shares': 20,
            'purchase_price': 380.00,
        },
    ]

    total_value = 0.0

    # Fetch current prices using yfinance
    for holding in predefined_holdings:
        stock = yf.Ticker(holding['symbol'])
        try:
            current_price = stock.history(period="1d")['Close'].iloc[-1]  # Get the latest closing price
            holding['current_price'] = round(current_price, 2)  # Update the holding with the current price

            shares = holding['shares']
            holding_value = shares * current_price
            total_value += holding_value

            # Calculate gain/loss percentage
            gain_loss_percentage = ((current_price - holding['purchase_price']) / holding['purchase_price']) * 100
            holding['gain_loss_percentage'] = round(gain_loss_percentage, 2)
            holding['current_value'] = round(holding_value, 2)
        except Exception as e:
            holding['current_price'] = "N/A"
            holding['gain_loss_percentage'] = "N/A"
            holding['current_value'] = "N/A"
            print(f"Error fetching data for {holding['symbol']}: {e}")

    context = {
        'total_value': round(total_value, 2),
        'holdings': predefined_holdings,
    }

    return render(request, 'dashboard/dashboard.html', context)

def get_timeframe_data(timeframe, holdings):
    # This function should return the data based on the selected timeframe
    data = {
        'labels': [],
        'portfolio_data': [],
        'benchmark_data': [],
    }

    # Define the date range based on the timeframe
    if timeframe == '1M':
        start_date = '2023-02-01'
        end_date = '2023-03-01'
    elif timeframe == '3M':
        start_date = '2022-12-01'
        end_date = '2023-03-01'
    elif timeframe == '6M':
        start_date = '2022-09-01'
        end_date = '2023-03-01'
    elif timeframe == '1Y':
        start_date = '2022-03-01'
        end_date = '2023-03-01'
    elif timeframe == 'ALL':
        start_date = '2020-01-01'
        end_date = '2023-03-01'

    # Fetch historical data for each holding
    for holding in holdings:
        stock = yf.Ticker(holding['symbol'])
        historical_data = stock.history(start=start_date, end=end_date)
        # Calculate portfolio data based on historical prices
        portfolio_values = (historical_data['Close'] * holding['shares']).tolist()
        data['portfolio_data'].append(sum(portfolio_values))  # Total value for the holding over the timeframe

    # Example benchmark data (you can replace this with actual S&P 500 data)
    benchmark_data = [35000, 36000, 37000, 38000, 39000, 40000]  # Dummy data for the benchmark
    data['benchmark_data'] = benchmark_data
        # Generate labels for the x-axis
    if timeframe == '1M':
        data['labels'] = ['Week 1', 'Week 2', 'Week 3', 'Week 4']
    elif timeframe == '3M':
        data['labels'] = ['Month 1', 'Month 2', 'Month 3']
    elif timeframe == '6M':
        data['labels'] = ['Month 1', 'Month 2', 'Month 3', 'Month 4', 'Month 5', 'Month 6']
    elif timeframe == '1Y':
        data['labels'] = ['Month 1', 'Month 2', 'Month 3', 'Month 4', 'Month 5', 'Month 6', 'Month 7', 'Month 8', 'Month 9', 'Month 10', 'Month 11', 'Month 12']
    elif timeframe == 'ALL':
        data['labels'] = ['Year 2020', 'Year 2021', 'Year 2022', 'Year 2023']

    return data


@login_required
def portfolio_view(request):
    portfolios = Portfolio.objects.filter(user=request.user)
    
    if request.method == 'POST':
        form = PortfolioForm(request.POST)
        if form.is_valid():
            portfolio = form.save(commit=False)
            portfolio.user = request.user
            portfolio.save()
            messages.success(request, 'Portfolio created successfully!')
            return redirect('portfolio')
    else:
        form = PortfolioForm()
    
    context = {
        'portfolios': portfolios,
        'form': form,
    }
    return render(request, 'dashboard/portfolio.html', context)

@login_required
def portfolio_detail(request, portfolio_id):
    portfolio = get_object_or_404(Portfolio, id=portfolio_id, user=request.user)
    holdings = Holding.objects.filter(portfolio=portfolio)
    
    if request.method == 'POST':
        form = HoldingForm(request.POST)
        if form.is_valid():
            holding = form.save(commit=False)
            holding.portfolio = portfolio
            
            # Get current price from API
            try:
                current_price = get_stock_price(holding.symbol)
                holding.current_price = current_price
            except Exception as e:
                messages.warning(request, f"Could not fetch current price: {str(e)}")
                holding.current_price = holding.purchase_price
            
            holding.save()
            
            # Create a buy transaction
            Transaction.objects.create(
                portfolio=portfolio,
                holding=holding,
                transaction_type='buy',
                symbol=holding.symbol,
                shares=holding.shares,
                price=holding.purchase_price,
                date=holding.purchase_date,
                total_amount=holding.shares * holding.purchase_price
            )
            
            messages.success(request, 'Holding added successfully!')
            return redirect('portfolio_detail', portfolio_id=portfolio.id)
    else:
        form = HoldingForm()
    
    context = {
        'portfolio': portfolio,
        'holdings': holdings,
        'form': form,
    }
    return render(request, 'dashboard/portfolio_detail.html', context)

@login_required
def update_prices(request, portfolio_id):
    portfolio = get_object_or_404(Portfolio, id=portfolio_id, user=request.user)
    holdings = Holding.objects.filter(portfolio=portfolio)
    
    updated_count = 0
    for holding in holdings:
        try:
            current_price = get_stock_price(holding.symbol)
            holding.current_price = current_price
            holding.save()
            updated_count += 1
        except Exception as e:
            messages.warning(request, f"Could not update price for {holding.symbol}: {str(e)}")
    
    messages.success(request, f'Updated prices for {updated_count} holdings.')
    return redirect('portfolio_detail', portfolio_id=portfolio.id)


def ai_advisor(request):
    if request.method == 'POST':
        form = ChatForm(request.POST)
        if form.is_valid():
            user_message = form.cleaned_data['message']
            
            # Save user message
            ChatMessage.objects.create(
                user=request.user,
                message=user_message,
                is_user_message=True
            )
            
            # Generate AI response
            ai_response = generate_ai_response(user_message)
            
            # Save AI response
            ChatMessage.objects.create(
                user=request.user,
                message=ai_response,
                is_user_message=False
            )
            
            # Possibly generate a recommendation
            if random.random() > 0.5:
                generate_recommendation(request.user, user_message)
                
            # If it's an AJAX request, return JSON
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'ai_response': ai_response
                })
    else:
        form = ChatForm()
    
    # Get chat history for this user
    chat_history = ChatMessage.objects.filter(user=request.user).order_by('created_at')
    recommendations = Recommendation.objects.filter(user=request.user).order_by('-created_at')
    
    return render(request, 'dashboard/ai_advisor.html', {
        'form': form,
        'chat_history': chat_history,
        'recommendations': recommendations
    })



def generate_ai_response(question):
    # This is a simple mock response generator
    # In a real app, you would call your AI service here
    
    question = question.lower()
    if "tax" in question:
        return "To reduce your tax liability, consider maximizing contributions to tax-advantaged accounts like 401(k)s and IRAs. Tax-loss harvesting can also offset capital gains. For more personalized advice, I'd need to know more about your specific financial situation."
    elif "rebalance" in question:
        return "Rebalancing your portfolio is generally recommended when your asset allocation drifts more than 5-10% from your target. Based on market conditions this year, it might be a good time to review your allocation. Would you like me to explain how to rebalance effectively?"
    elif "allocation" in question or "risk" in question:
        return "A good asset allocation depends on your risk tolerance, time horizon, and financial goals. For moderate risk tolerance, a common starting point is 60% stocks and 40% bonds. As you get closer to retirement, you might want to shift toward more conservative allocations. Would you like me to suggest a specific allocation based on your age and risk profile?"
    else:
        return "That's a great question about financial planning. To give you the most helpful advice, could you provide more details about your specific situation and goals?"

def generate_recommendation(user, question):
    question = question.lower()
    
    if "tax" in question:
        Recommendation.objects.create(
            user=user,
            title="Tax Optimization Strategy",
            description="Consider tax-loss harvesting to offset capital gains and reduce your tax burden.",
            recommendation_type="warning"
        )
    elif "rebalance" in question or "portfolio" in question:
        Recommendation.objects.create(
            user=user,
            title="Portfolio Rebalancing",
            description="Your portfolio may benefit from rebalancing to maintain your target asset allocation.",
            recommendation_type="primary"
        )
    else:
        Recommendation.objects.create(
            user=user,
            title="Investment Opportunity",
            description="Based on your risk profile, consider diversifying into emerging markets for potential growth.",
            recommendation_type="success"
)

@login_required
def tax_tools(request):
    if request.method == 'POST':
        form = TaxCalculationForm(request.POST)
        if form.is_valid():
            tax_calc = form.save(commit=False)
            tax_calc.user = request.user
            
            # Calculate tax liability
            tax_result = calculate_tax_liability(
                annual_income=tax_calc.annual_income,
                capital_gains=tax_calc.capital_gains,
                filing_status=tax_calc.filing_status,
                state=tax_calc.state
            )
            
            tax_calc.federal_tax = tax_result['federal_tax']
            tax_calc.state_tax = tax_result['state_tax']
            tax_calc.capital_gains_tax = tax_result['capital_gains_tax']
            tax_calc.total_tax = tax_result['total_tax']
            tax_calc.save()
            
            context = {
                'form': form,
                'tax_result': tax_result,
                'tax_calc': tax_calc,
            }
            return render(request, 'dashboard/tax_tools.html', context)
    else:
        # Pre-fill form with user profile data if available
        initial_data = {}
        try:
            profile = UserProfile.objects.get(user=request.user)
            initial_data = {
                'annual_income': profile.annual_income,
                'filing_status': profile.tax_filing_status,
                'state': profile.state_of_residence,
                'year': datetime.datetime.now().year,
            }
        except UserProfile.DoesNotExist:
            pass
        
        form = TaxCalculationForm(initial=initial_data)
    
    # Get previous tax calculations
    previous_calculations = TaxCalculation.objects.filter(user=request.user).order_by('-created_at')[:5]
    
    context = {
        'form': form,
        'previous_calculations': previous_calculations,
    }
    return render(request, 'dashboard/tax_tools.html', context)

@login_required
def get_portfolio_data(request, portfolio_id):
    portfolio = get_object_or_404(Portfolio, id=portfolio_id, user=request.user)
    holdings = Holding.objects.filter(portfolio=portfolio)
    
    # Prepare data for charts
    labels = [holding.symbol for holding in holdings]
    values = [float(holding.current_value) for holding in holdings]
    colors = [f'rgba({hash(holding.symbol) % 255}, {(hash(holding.symbol) * 2) % 255}, {(hash(holding.symbol) * 3) % 255}, 0.7)' for holding in holdings]
    
    data = {
        'labels': labels,
        'values': values,
        'colors': colors,
    }
    
    return JsonResponse(data)

@login_required
def get_stock_history(request, symbol):
    try:
        data = get_stock_data(symbol)
        return JsonResponse(data)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=400)
    


def blog(request):
    return render(request, 'dashboard/blog.html')

from django.views.generic import TemplateView

class HelpCenterView(TemplateView):
    template_name = 'help_center.html'

from django.shortcuts import render

def help_center(request):
    return render(request, 'dashboard/help_center.html')

from django.shortcuts import render

def privacy_policy(request):
    return render(request, 'dashboard/privacy_policy.html')

def terms_of_service(request):
    return render(request, 'dashboard/terms_of_service.html')

def compliance(request):
    return render(request, 'dashboard/compliance.html')