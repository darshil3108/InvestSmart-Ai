from django.db import models
from django.contrib.auth.models import User

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    risk_tolerance = models.CharField(max_length=20, choices=[
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High')
    ], default='medium')
    investment_goal = models.CharField(max_length=100, blank=True)
    annual_income = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    tax_filing_status = models.CharField(max_length=20, choices=[
        ('single', 'Single'),
        ('married_joint', 'Married Filing Jointly'),
        ('married_separate', 'Married Filing Separately'),
        ('head', 'Head of Household')
    ], default='single')
    state_of_residence = models.CharField(max_length=2, default='CA')
    
    def __str__(self):
        return f"{self.user.username}'s Profile"

class Portfolio(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.name} ({self.user.username})"
    
    def total_value(self):
        return sum(holding.current_value for holding in self.holding_set.all())

class Holding(models.Model):
    portfolio = models.ForeignKey(Portfolio, on_delete=models.CASCADE)
    symbol = models.CharField(max_length=10)
    name = models.CharField(max_length=100)
    shares = models.DecimalField(max_digits=12, decimal_places=4)
    purchase_price = models.DecimalField(max_digits=12, decimal_places=2)
    purchase_date = models.DateField()
    current_price = models.DecimalField(max_digits=12, decimal_places=2)
    last_updated = models.DateTimeField(auto_now=True)
    sector = models.CharField(max_length=50, blank=True)
    
    def __str__(self):
        return f"{self.symbol} - {self.shares} shares"
    
    @property
    def current_value(self):
        return self.shares * self.current_price
    
    @property
    def gain_loss(self):
        return self.current_value - (self.shares * self.purchase_price)
    
    @property
    def gain_loss_percentage(self):
        purchase_value = self.shares * self.purchase_price
        if purchase_value == 0:
            return 0
        return (self.gain_loss / purchase_value) * 100

class Transaction(models.Model):
    TRANSACTION_TYPES = [
        ('buy', 'Buy'),
        ('sell', 'Sell'),
        ('dividend', 'Dividend'),
        ('split', 'Split'),
    ]
    
    portfolio = models.ForeignKey(Portfolio, on_delete=models.CASCADE)
    holding = models.ForeignKey(Holding, on_delete=models.CASCADE, null=True, blank=True)
    transaction_type = models.CharField(max_length=10, choices=TRANSACTION_TYPES)
    symbol = models.CharField(max_length=10)
    shares = models.DecimalField(max_digits=12, decimal_places=4)
    price = models.DecimalField(max_digits=12, decimal_places=2)
    date = models.DateField()
    total_amount = models.DecimalField(max_digits=12, decimal_places=2)
    
    def __str__(self):
        return f"{self.transaction_type} {self.shares} shares of {self.symbol}"

class AIRecommendation(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    description = models.TextField()
    recommendation_type = models.CharField(max_length=50, choices=[
        ('portfolio', 'Portfolio Optimization'),
        ('tax', 'Tax Strategy'),
        ('risk', 'Risk Management'),
    ])
    created_at = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False)
    
    def __str__(self):
        return f"{self.title} ({self.user.username})"

class ChatMessage(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    message = models.TextField()
    is_user_message = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['created_at']

class Recommendation(models.Model):
    RECOMMENDATION_TYPES = (
        ('primary', 'Primary'),
        ('success', 'Success'),
        ('warning', 'Warning'),
    )
    
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField(max_length=100)
    description = models.TextField()
    recommendation_type = models.CharField(max_length=20, choices=RECOMMENDATION_TYPES)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering =['-created_at']

class TaxCalculation(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    year = models.IntegerField()
    annual_income = models.DecimalField(max_digits=12, decimal_places=2)
    capital_gains = models.DecimalField(max_digits=12, decimal_places=2)
    filing_status = models.CharField(max_length=20)
    state = models.CharField(max_length=2)
    federal_tax = models.DecimalField(max_digits=12, decimal_places=2)
    state_tax = models.DecimalField(max_digits=12, decimal_places=2)
    capital_gains_tax = models.DecimalField(max_digits=12, decimal_places=2)
    total_tax = models.DecimalField(max_digits=12, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Tax Calculation for {self.user.username} ({self.year})"
    

# models.py
class AssetAllocation(models.Model):
    asset_type = models.CharField(max_length=100)
    value = models.DecimalField(max_digits=10, decimal_places=2)


class TaxProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    income = models.DecimalField(max_digits=10, decimal_places=2)
    investment_type = models.CharField(max_length=100)
    holding_period = models.CharField(max_length=50, choices=[('short-term', 'Short-Term'), ('long-term', 'Long-Term')])
    capital_gains = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    deductions_80C = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    deductions_80D = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    deductions_80E = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    home_loan_interest = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)

    def __str__(self):
        return f"Tax Profile - {self.user.username}"