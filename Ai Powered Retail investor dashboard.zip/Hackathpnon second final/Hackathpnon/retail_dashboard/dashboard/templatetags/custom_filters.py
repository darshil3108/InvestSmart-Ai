from django import template

register = template.Library()

@register.filter
def percentage(value, total):
    try:
        return (float(value) / float(total)) * 100 if total else 0
    except (ValueError, ZeroDivisionError):
        return 0
