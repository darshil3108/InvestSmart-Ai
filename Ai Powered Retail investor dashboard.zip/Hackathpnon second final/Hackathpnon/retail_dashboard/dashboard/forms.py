from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import UserProfile, Portfolio, Holding, Transaction, TaxCalculation
from .models import TaxProfile
class UserRegistrationForm(UserCreationForm):
    email = forms.EmailField(required=True)
    
    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']

class UserProfileForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['risk_tolerance', 'investment_goal', 'annual_income', 'tax_filing_status', 'state_of_residence']
        widgets = {
            'investment_goal': forms.TextInput(attrs={'placeholder': 'e.g., Retirement, College Fund, etc.'}),
        }

class PortfolioForm(forms.ModelForm):
    class Meta:
        model = Portfolio
        fields = ['name', 'description']

class HoldingForm(forms.ModelForm):
    class Meta:
        model = Holding
        fields = ['symbol', 'name', 'shares', 'purchase_price', 'purchase_date', 'sector']
        widgets = {
            'purchase_date': forms.DateInput(attrs={'type': 'date'}),
        }

class TransactionForm(forms.ModelForm):
    class Meta:
        model = Transaction
        fields = ['transaction_type', 'symbol', 'shares', 'price', 'date']
        widgets = {
            'date': forms.DateInput(attrs={'type': 'date'}),
        }
    
    def clean(self):
        cleaned_data = super().clean()
        shares = cleaned_data.get('shares')
        price = cleaned_data.get('price')
        
        if shares and price:
            cleaned_data['total_amount'] = shares * price
        
        return cleaned_data

class TaxCalculationForm(forms.ModelForm):
    class Meta:
        model = TaxCalculation
        fields = ['year', 'annual_income', 'capital_gains', 'filing_status', 'state']
        widgets = {
            'year': forms.NumberInput(attrs={'min': 2000, 'max': 2030}),
        }

class AIAdvisorForm(forms.Form):
    message = forms.CharField(widget=forms.Textarea(attrs={'rows': 3, 'placeholder': 'Ask about your investments, tax strategies, or portfolio allocation...'}))

class ChatForm(forms.Form):
    message = forms.CharField(
        widget=forms.TextInput(
            attrs={
                'class': 'form-control',
                'placeholder': 'Type your question here...',
                'id': 'id_message'
            }
        ),
        required=True
)
    
class TaxProfileForm(forms.ModelForm):
    class Meta:
        model = TaxProfile
        fields = ['income', 'investment_type', 'holding_period', 'capital_gains',
                  'deductions_80C', 'deductions_80D', 'deductions_80E', 'home_loan_interest']