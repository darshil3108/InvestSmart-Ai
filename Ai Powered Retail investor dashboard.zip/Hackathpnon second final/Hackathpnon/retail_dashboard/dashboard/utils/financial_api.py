import requests
from django.conf import settings
import json
import datetime

def get_stock_price(symbol):
    """Get current stock price from Alpha Vantage API"""
    try:
        url = f"https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol={symbol}&apikey={settings.ALPHA_VANTAGE_API_KEY}"
        response = requests.get(url)
        data = response.json()
        
        if "Global Quote" in data and "05. price" in data["Global Quote"]:
            return float(data["Global Quote"]["05. price"])
        else:
            # Fallback to mock data if API fails or rate limit exceeded
            return get_mock_stock_price(symbol)
    except Exception:
        # Fallback to mock data
        return get_mock_stock_price(symbol)

def get_mock_stock_price(symbol):
    """Generate mock stock price for demo purposes"""
    # This is a simple hash function to generate consistent mock prices
    price_base = sum(ord(c) for c in symbol) % 1000
    return price_base + (price_base * 0.01)

def get_stock_data(symbol):
    """Get historical stock data from Alpha Vantage API"""
    try:
        url = f"https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol={symbol}&apikey={settings.ALPHA_VANTAGE_API_KEY}&outputsize=compact"
        response = requests.get(url)
        data = response.json()
        
        if "Time Series (Daily)" in data:
            time_series = data["Time Series (Daily)"]
            dates = []
            prices = []
            
            for date, values in time_series.items():
                dates.append(date)
                prices.append(float(values["4. close"]))
            
            # Reverse to get chronological order
            dates.reverse()
            prices.reverse()
            
            return {
                "dates": dates,
                "prices": prices
            }
        else:
            # Fallback to mock data if API fails or rate limit exceeded
            return get_mock_stock_data(symbol)
    except Exception:
        # Fallback to mock data
        return get_mock_stock_data(symbol)

def get_mock_stock_data(symbol):
    """Generate mock stock data for demo purposes"""
    # Generate 30 days of mock data
    dates = []
    prices = []
    
    base_price = sum(ord(c) for c in symbol) % 1000
    current_price = base_price
    
    today = datetime.datetime.now()
    
    for i in range(30):
        date = today - datetime.timedelta(days=29-i)
        dates.append(date.strftime("%Y-%m-%d"))
        
        # Add some randomness to the price
        change = (hash(symbol + str(i)) % 100 - 50) / 500
        current_price = max(0.01, current_price * (1 + change))
        prices.append(round(current_price, 2))
    
    return {
        "dates": dates,
        "prices": prices
    }

