// Common chart functions for the dashboard

// Initialize portfolio performance chart
function initPortfolioChart(chartId, labels, portfolioData, benchmarkData) {
    const ctx = document.getElementById(chartId).getContext('2d');
    
    return new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Your Portfolio',
                data: portfolioData,
                borderColor: '#4f46e5',
                backgroundColor: 'rgba(79, 70, 229, 0.1)',
                borderWidth: 2,
                fill: true,
                tension: 0.4
            }, {
                label: 'S&P 500',
                data: benchmarkData,
                borderColor: '#10b981',
                borderWidth: 2,
                borderDash: [5, 5],
                fill: false,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                    callbacks: {
                        label: function(context) {
                            let label = context.dataset.label || '';
                            if (label) {
                                label += ': ';
                            }
                            if (context.parsed.y !== null) {
                                label += new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(context.parsed.y);
                            }
                            return label;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: false,
                    ticks: {
                        callback: function(value) {
                            return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', notation: 'compact' }).format(value);
                        }
                    }
                }
            }
        }
    });
}

// Initialize asset allocation chart
function initAssetAllocationChart(chartId, labels, data) {
    const ctx = document.getElementById(chartId).getContext('2d');
    
    const colors = [
        '#4f46e5', // Primary
        '#10b981', // Secondary
        '#f59e0b', // Warning
        '#ef4444', // Danger
        '#3b82f6', // Info
        '#8b5cf6', // Purple
        '#ec4899', // Pink
        '#6b7280'  // Gray
    ];
    
    return new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: colors.slice(0, labels.length),
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.parsed || 0;
                            return `${label}: ${value.toFixed(2)}%`;
                        }
                    }
                }
            }
        }
    });
}

// Update chart data based on timeframe
function updateChartTimeframe(chart, timeframe, portfolioData, benchmarkData) {
    let labels = [];
    let portfolioValues = [];
    let benchmarkValues = [];
    
    switch(timeframe) {
        case '1M':
            labels = portfolioData.dates.slice(-30);
            portfolioValues = portfolioData.values.slice(-30);
            benchmarkValues = benchmarkData.values.slice(-30);
            break;
        case '3M':
            labels = portfolioData.dates.slice(-90);
            portfolioValues = portfolioData.values.slice(-90);
            benchmarkValues = benchmarkData.values.slice(-90);
            break;
        case '6M':
            labels = portfolioData.dates.slice(-180);
            portfolioValues = portfolioData.values.slice(-180);
            benchmarkValues = benchmarkData.values.slice(-180);
            break;
        case '1Y':
            labels = portfolioData.dates.slice(-365);
            portfolioValues = portfolioData.values.slice(-365);
            benchmarkValues = benchmarkData.values.slice(-365);
            break;
        case 'ALL':
            labels = portfolioData.dates;
            portfolioValues = portfolioData.values;
            benchmarkValues = benchmarkData.values;
            break;
    }
    
    chart.data.labels = labels;
    chart.data.datasets[0].data = portfolioValues;
    chart.data.datasets[1].data = benchmarkValues;
    chart.update();
}