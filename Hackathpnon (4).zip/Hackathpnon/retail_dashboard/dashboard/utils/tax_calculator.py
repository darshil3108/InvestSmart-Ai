def calculate_tax_liability(annual_income, capital_gains, filing_status, state):
    """Calculate estimated tax liability"""
    # Federal tax brackets for 2023 (simplified)
    federal_brackets = {
        'single': [
            (0, 11000, 0.10),
            (11001, 44725, 0.12),
            (44726, 95375, 0.22),
            (95376, 182100, 0.24),
            (182101, 231250, 0.32),
            (231251, 578125, 0.35),
            (578126, float('inf'), 0.37)
        ],
        'married_joint': [
            (0, 22000, 0.10),
            (22001, 89450, 0.12),
            (89451, 190750, 0.22),
            (190751, 364200, 0.24),
            (364201, 462500, 0.32),
            (462501, 693750, 0.35),
            (693751, float('inf'), 0.37)
        ],
        'married_separate': [
            (0, 11000, 0.10),
            (11001, 44725, 0.12),
            (44726, 95375, 0.22),
            (95376, 182100, 0.24),
            (182101, 231250, 0.32),
            (231251, 346875, 0.35),
            (346876, float('inf'), 0.37)
        ],
        'head': [
            (0, 15700, 0.10),
            (15701, 59850, 0.12),
            (59851, 95350, 0.22),
            (95351, 182100, 0.24),
            (182101, 231250, 0.32),
            (231251, 578100, 0.35),
            (578101, float('inf'), 0.37)
        ]
    }
    
    # State tax rates (simplified)
    state_tax_rates = {
        'CA': 0.093,
        'NY': 0.068,
        'TX': 0.0,
        'FL': 0.0,
        'WA': 0.0,
        'NV': 0.0,
        'AK': 0.0,
        'WY': 0.0,
        'SD': 0.0,
        'TN': 0.0,
        'NH': 0.0,
        'DE': 0.066,
        'OR': 0.099,
        'MA': 0.05,
        'IL': 0.0495,
        'PA': 0.0307,
        'VA': 0.0575,
        'NC': 0.0499,
        'GA': 0.0575,
        'OH': 0.0399,
        'MI': 0.0425,
        'AZ': 0.045,
        'CO': 0.0455,
        'UT': 0.0495,
        'ID': 0.06,
        'MT': 0.0675,
        'NM': 0.059,
        'HI': 0.11,
        'ME': 0.0715,
        'VT': 0.0875,
        'RI': 0.0599,
        'CT': 0.0699,
        'NJ': 0.1075,
        'MD': 0.0575,
        'MN': 0.0985,
        'WI': 0.0765,
        'IA': 0.0625,
        'MO': 0.054,
        'AR': 0.055,
        'LA': 0.0425,
        'MS': 0.05,
        'AL': 0.05,
        'KY': 0.05,
        'IN': 0.0323,
        'KS': 0.057,
        'NE': 0.0684,
        'OK': 0.0475,
        'SC': 0.07,
        'WV': 0.065,
        'ND': 0.0275,
        'DC': 0.0895,
    }
    
    # Capital gains tax rates (simplified)
    capital_gains_rates = {
        'low': 0.0,    # For income below $44,625 (single)
        'medium': 0.15,  # For income between $44,625 and $492,300 (single)
        'high': 0.20    # For income above $492,300 (single)
    }
    
    # Calculate federal income tax
    federal_tax = 0
    brackets = federal_brackets.get(filing_status, federal_brackets['single'])
    
    for i, (lower, upper, rate) in enumerate(brackets):
        if annual_income > lower:
            taxable_amount = min(annual_income, upper) - lower
            federal_tax += taxable_amount * rate
    
    # Calculate state income tax (simplified)
    state_rate = state_tax_rates.get(state.upper(), 0.05)  # Default to 5% if state not found
    state_tax = annual_income * state_rate
    
    # Calculate capital gains tax (simplified)
    if annual_income < 44625:
        capital_gains_rate = capital_gains_rates['low']
    elif annual_income < 492300:
        capital_gains_rate = capital_gains_rates['medium']
    else:
        capital_gains_rate = capital_gains_rates['high']
    
    capital_gains_tax = capital_gains * capital_gains_rate
    
    # Calculate total tax
    total_tax = federal_tax + state_tax + capital_gains_tax
    
    # Calculate effective tax rate
    effective_tax_rate = (total_tax / (annual_income + capital_gains)) * 100 if (annual_income + capital_gains) > 0 else 0
    
    return {
        'federal_tax': federal_tax,
        'state_tax': state_tax,
        'capital_gains_tax': capital_gains_tax,
        'total_tax': total_tax,
        'effective_tax_rate': effective_tax_rate,
        'tax_brackets': brackets,
        'capital_gains_rate': capital_gains_rate,
        'state_tax_rate': state_rate
    }