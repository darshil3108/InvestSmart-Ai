import yfinance as yf

def fetch_current_price(symbol):
    try:
        stock = yf.Ticker(symbol)
        data = stock.history(period="1d")
        current_price = data['Close'].iloc[-1] if not data.empty else 0.0
        return round(current_price, 2)  # Round to 2 decimal places
    except Exception as e:
        print(f"Error fetching data for {symbol}: {e}")
        return 0.0