import openai
from django.conf import settings
from ..models import Portfolio, Holding, UserProfile

openai.api_key = settings.OPENAI_API_KEY

def get_portfolio_summary(user):
    """Generate a summary of the user's portfolio for AI context"""
    try:
        portfolios = Portfolio.objects.filter(user=user)
        summary = []
        
        for portfolio in portfolios:
            holdings = Holding.objects.filter(portfolio=portfolio)
            portfolio_value = sum(holding.current_value for holding in holdings)
            
            summary.append(f"Portfolio: {portfolio.name}")
            summary.append(f"Total Value: ${portfolio_value:.2f}")
            summary.append("Holdings:")
            
            for holding in holdings:
                summary.append(f"- {holding.symbol}: {holding.shares} shares at ${holding.current_price:.2f}, " +
                              f"total value: ${holding.current_value:.2f}, " +
                              f"gain/loss: ${holding.gain_loss:.2f} ({holding.gain_loss_percentage:.2f}%)")
        
        try:
            profile = UserProfile.objects.get(user=user)
            summary.append(f"Risk Tolerance: {profile.risk_tolerance}")
            summary.append(f"Investment Goal: {profile.investment_goal}")
        except UserProfile.DoesNotExist:
            pass
            
        return "\n".join(summary)
    except Exception as e:
        return f"Error generating portfolio summary: {str(e)}"

def get_ai_response(user_message, user):
    """Get AI response to user message"""
    portfolio_summary = get_portfolio_summary(user)
    
    system_message = """
    You are an AI financial advisor specializing in helping retail investors make informed decisions.
    You provide personalized investment advice based on the user's portfolio, financial goals, and risk tolerance.
    You also help with tax optimization strategies and regulatory compliance.
    Keep your responses concise, informative, and tailored to the user's specific situation.
    """
    
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": system_message},
                {"role": "user", "content": f"Here is my portfolio information:\n{portfolio_summary}\n\nMy question is: {user_message}"}
            ],
            max_tokens=500,
            temperature=0.7
        )
        
        return response.choices[0].message.content
    except Exception as e:
        return f"I'm sorry, I'm having trouble generating a response right now. Please try again later. Error: {str(e)}"

def get_ai_recommendation(user):
    """Generate an AI recommendation based on user's portfolio"""
    portfolio_summary = get_portfolio_summary(user)
    
    system_message = """
    You are an AI financial advisor. Based on the user's portfolio information, generate a specific, actionable recommendation.
    Your recommendation should be in the following JSON format:
    {
        "title": "Brief title of the recommendation",
        "description": "Detailed explanation of the recommendation",
        "type": "One of: portfolio, tax, risk"
    }
    """
    
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": system_message},
                {"role": "user", "content": f"Here is my portfolio information:\n{portfolio_summary}\n\nGenerate a recommendation."}
            ],
            max_tokens=500,
            temperature=0.7
        )
        
        recommendation = response.choices[0].message.content
        # Parse JSON from the response
        import json
        try:
            return json.loads(recommendation)
        except:
            # Fallback if JSON parsing fails
            return {
                "title": "Portfolio Review Recommended",
                "description": "It's a good time to review your portfolio allocation and ensure it aligns with your financial goals.",
                "type": "portfolio"
            }
    except Exception as e:
        return {
            "title": "Portfolio Review Recommended",
            "description": f"It's a good time to review your portfolio allocation. (Note: AI recommendation service is currently experiencing issues: {str(e)})",
            "type": "portfolio"
        }