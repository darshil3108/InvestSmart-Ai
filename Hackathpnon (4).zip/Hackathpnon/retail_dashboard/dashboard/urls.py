from django.urls import path
from . import views
from django.contrib.auth import views as auth_views
from django.shortcuts import redirect 

urlpatterns = [
    path('', views.index, name='index'),
    path("accounts/profile/", lambda request: redirect("dashboard/"), name="profile_redirect"),
    path('register/', views.register, name='register'),
    
    path('login/', auth_views.LoginView.as_view(template_name='dashboard/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(next_page='index'), name='logout'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('portfolio/', views.portfolio_view, name='portfolio'),
    path('portfolio/<int:portfolio_id>/', views.portfolio_detail, name='portfolio_detail'),
    path('portfolio/<int:portfolio_id>/update-prices/', views.update_prices, name='update_prices'),
    path('ai-advisor/', views.ai_advisor, name='ai_advisor'),
    path('tax-tools/', views.tax_tools, name='tax_tools'),
    path('api/portfolio-data/<int:portfolio_id>/', views.get_portfolio_data, name='get_portfolio_data'),
    path('api/stock-history/<str:symbol>/', views.get_stock_history, name='get_stock_history'),
]